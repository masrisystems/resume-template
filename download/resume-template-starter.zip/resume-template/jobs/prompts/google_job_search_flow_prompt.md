# Google Direct ATS & Job Sourcing Flow Prompt

> **Purpose:** Find hidden, direct-company job postings on Google and official ATS portals (Personio, Greenhouse, Lever, Join.com, Workwise) — completely bypassing recruiter spam, expired agency listings, and job board middlemen. Designed for fresh graduates, career switchers, and software professionals.

---

### AI Prompt (Copy & Run in ChatGPT, Claude, Perplexity, or Gemini)

```markdown
# Role & Expertise
You are an Executive Tech Sourcing Specialist and Google Search Architect. Your mission is to find verified, direct-employer job openings for fresh graduates and technical professionals by executing Google Dorking techniques and querying native Applicant Tracking Systems (ATS). You bypass recruitment agencies, outdated aggregator reposts, and third-party spam.

# Candidate Context
Read the candidate profile in `@config/profile.json` (or use the following parameters):
- Target Profession: {{PROFESSION}} (e.g., Junior / Associate Fullstack Softwareentwickler, Frontend Developer, Cloud DevOps)
- Target Technologies: {{TECH_STACK}} (e.g., TypeScript, Vue.js, React, Python, PHP/Laravel, Docker)
- Target Location & Commute: {{LOCATION}} (e.g., Oldenburg + 25 km commute or 100% Remote Germany)
- Target Salary / Invariant: {{TARGET_SALARY}} (e.g., 52.500 € gross/year)
- Notice Period / Availability: {{NOTICE_PERIOD}} (e.g., 3 Monate zum Monatsende)

---

# Execution Phase 1: Google Dorking for Direct ATS Portals
Execute precision Google searches directly targeting company ATS platforms where applications go straight to the hiring manager:

1. **Target ATS Portals:**
   `site:personio.de | site:join.com | site:greenhouse.io | site:lever.co | site:workwise.io | site:recruitee.com | site:onlyfy.jobs`

2. **Job Title & Seniority Filter (Include Graduate/Entry Level keywords):**
   `("Junior" OR "Absolvent" OR "Entry Level" OR "Berufseinsteiger" OR "Associate" OR "Fullstack" OR "Softwareentwickler")`

3. **Required Skills / Tech Keywords:**
   `("TypeScript" OR "Python" OR "Vue" OR "React" OR "Laravel")`

4. **Location & Remote Preference:**
   `("{{LOCATION}}" OR "Remote Deutschland" OR "Homeoffice")`

5. **Exclusion of Middlemen & Agencies (Negative Keywords):**
   `-Zeitarbeit -Personalvermittlung -Headhunter -Personalberatung -Vermittlung -Freelance -Praktikant`

6. **Freshness Parameter:**
   Filter results to the last 24 hours to 7 days (`after:2026-09-01` or Google `qdr:w` / `qdr:d`).

---

# Execution Phase 2: Google for Jobs Direct Launch Queries
Generate 3 pre-built Google Search URLs that open the interactive Google for Jobs interface directly:
1. `https://www.google.com/search?q={{PROFESSION}}+{{LOCATION}}+jobs&ibp=htl;jobs`
2. `https://www.google.com/search?q={{TECH_STACK}}+Junior+Developer+Remote+Deutschland+jobs&ibp=htl;jobs`
3. `https://www.google.com/search?q=site:personio.de+{{PROFESSION}}+{{LOCATION}}&ibp=htl;jobs`

---

# Execution Phase 3: Kununu Employer & Salary Due Diligence via Google
For every promising employer found, run a 60-second background check:
1. **Kununu Reputation Check:**
   Google query: `site:kununu.com/de "{{COMPANY_NAME}}"`
   - Evaluate Score (Target: >= 3.7 / 5.0) and recommendation rate (>= 70%).
2. **Salary Reality Benchmark:**
   Google query: `site:kununu.com/de "{{COMPANY_NAME}}" "Gehalt" OR "{{PROFESSION}}"`
   - Verify if their typical compensation matches the candidate's target invariant (e.g., ~52.500 €).

---

# Execution Phase 4: Output for the Application Tracking Ledger
Format the top 2-3 qualifying opportunities as continuous Markdown rows ready to be appended to `@jobs/job_matches.md`:

| Job Title | Company Name | Location | Job Type | Status | Match Score (0-10) | Match Justification | Skill Gap | Salary Range | Apply Link |

### Column Formatting Rules:
- **Status:** Set to `🟢 [New]`.
- **Match Score:** Calculate 0.0 to 10.0 (70% required skills + 30% preferred skills). Must score >= 9.0/10 to qualify.
- **Match Justification:** 1 concise sentence highlighting why this matches the candidate's degree and core tech stack.
- **Skill Gap:** 1 specific technology from the posting not currently highlighted in the resume.
- **Salary Range:** Kununu or official posting salary range benchmark.
- **Apply Link:** Direct link to the official company career portal or direct ATS form (never an aggregator redirect).
```
